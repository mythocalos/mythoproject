﻿using Abp.MultiTenancy;
using MythoProject.Authorization.Users;

namespace MythoProject.MultiTenancy
{
    public class Tenant : AbpTenant<User>
    {
        public Tenant()
        {
            
        }

        public Tenant(string tenancyName, string name)
            : base(tenancyName, name)
        {
        }
    }
}