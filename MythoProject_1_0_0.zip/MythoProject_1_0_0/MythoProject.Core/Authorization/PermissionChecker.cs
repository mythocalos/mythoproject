﻿using Abp.Authorization;
using MythoProject.Authorization.Roles;
using MythoProject.Authorization.Users;

namespace MythoProject.Authorization
{
    public class PermissionChecker : PermissionChecker<Role, User>
    {
        public PermissionChecker(UserManager userManager)
            : base(userManager)
        {

        }
    }
}
