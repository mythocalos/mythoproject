﻿namespace MythoProject
{
    public class MythoProjectConsts
    {
        public const string LocalizationSourceName = "MythoProject";

        public const bool MultiTenancyEnabled = true;
    }
}