﻿using Abp.Application.Services;
using Abp.Application.Services.Dto;
using MythoProject.MultiTenancy.Dto;

namespace MythoProject.MultiTenancy
{
    public interface ITenantAppService : IAsyncCrudAppService<TenantDto, int, PagedResultRequestDto, CreateTenantDto, TenantDto>
    {
    }
}
