﻿using System.Threading.Tasks;
using Abp.Application.Services;
using MythoProject.Configuration.Dto;

namespace MythoProject.Configuration
{
    public interface IConfigurationAppService: IApplicationService
    {
        Task ChangeUiTheme(ChangeUiThemeInput input);
    }
}