﻿using System.Threading.Tasks;
using Abp.Application.Services;
using MythoProject.Sessions.Dto;

namespace MythoProject.Sessions
{
    public interface ISessionAppService : IApplicationService
    {
        Task<GetCurrentLoginInformationsOutput> GetCurrentLoginInformations();
    }
}
