﻿using Abp.Domain.Entities;
using Abp.EntityFramework;
using Abp.EntityFramework.Repositories;

namespace MythoProject.EntityFramework.Repositories
{
    public abstract class MythoProjectRepositoryBase<TEntity, TPrimaryKey> : EfRepositoryBase<MythoProjectDbContext, TEntity, TPrimaryKey>
        where TEntity : class, IEntity<TPrimaryKey>
    {
        protected MythoProjectRepositoryBase(IDbContextProvider<MythoProjectDbContext> dbContextProvider)
            : base(dbContextProvider)
        {

        }

        //add common methods for all repositories
    }

    public abstract class MythoProjectRepositoryBase<TEntity> : MythoProjectRepositoryBase<TEntity, int>
        where TEntity : class, IEntity<int>
    {
        protected MythoProjectRepositoryBase(IDbContextProvider<MythoProjectDbContext> dbContextProvider)
            : base(dbContextProvider)
        {

        }

        //do not add any method here, add to the class above (since this inherits it)
    }
}
