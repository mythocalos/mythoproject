﻿using System.Web.Mvc;

namespace MythoProject.Web.Controllers
{
    public class AboutController : MythoProjectControllerBase
    {
        public ActionResult Index()
        {
            return View();
        }
	}
}